var Klubmodul = Klubmodul || {};
Klubmodul.UserProfileController = function () {
    this.$divClubName = null;
    this.$divFirstName = null;
    this.$divLastName = null;
};

Klubmodul.UserProfileController.prototype.init = function () {
    var me = this;
    var invisibleStyle = "bi-invisible",
        invalidInputStyle = "bi-invalid-input";
    this.$signInPage = $("#page-signin");
    this.mainMenuPageId = "#page-memberdetails";
    this.$divClubName = $("#div-club-name", this.$divClubName);
    this.$divFirstName = $("#div-first-name", this.$divFirstName);
    this.$divLastName = $("#div-last-name", this.$divLastName);
    this.$ctnErr = $("#ctn-err", this.$mainMenuPageId);
};


Klubmodul.UserProfileController.prototype.setUserProfile = function () {
    var invisibleStyle = "bi-invisible",
        invalidInputStyle = "bi-invalid-input";
    var sessionObject = Klubmodul.Session.getInstance().get();
    if(sessionObject != null && sessionObject.userProfileModel != null)
    {
    this.$ctnErr.html("");
    this.$ctnErr.removeClass().addClass(invisibleStyle);
    this.$divClubName.html(sessionObject.userProfileModel.ClubName);
    this.$divFirstName.html(sessionObject.userProfileModel.FirstName);
    this.$divLastName.html(sessionObject.userProfileModel.LastName);
  }
  else {
    this.$ctnErr.html("Unbale to find session, please try to login again.");
    this.$ctnErr.removeClass();
  }
};
