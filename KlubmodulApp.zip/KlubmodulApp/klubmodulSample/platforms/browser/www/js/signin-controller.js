var Klubmodul = Klubmodul || {};
Klubmodul.SignInController = function () {
    this.$signInPage = null;
    this.$btnSubmit = null;
    this.$txtUserName = null;
    this.$txtPassword = null;
    this.$chkKeepSignedIn = null;
    this.$ctnErr = null;
    this.mainMenuPageId = null;
    this.$ddlKlubs = null;
};

Klubmodul.SignInController.prototype.init = function () {
    var me = this;
    var invisibleStyle = "bi-invisible",
        invalidInputStyle = "bi-invalid-input";
    this.$signInPage = $("#page-signin");
    this.mainMenuPageId = "#page-memberdetails";
    this.$btnSubmit = $("#btn-submit", this.$signInPage);
    this.$ctnErr = $("#ctn-err", this.$signInPage);
    this.$txtUserName = $("#txt-user-name", this.$signInPage);
    this.$txtPassword = $("#txt-password", this.$signInPage);
    this.$chkKeepSignedIn = $("#chk-keep-signed-in", this.$signInPage);
    this.$ddlKlubs = $("#ddl-klubs", this.$ddlKlubs);

    $.ajax({
        type: 'POST',
        url: Klubmodul.Settings.getAllKlubUrl,
        data: "",
        contentType: "application/json",
        dataType: "json",
        crossDomain: true,
        success: function (resp) {
            $.mobile.loading("hide");
                var appenddata;
                appenddata += "<option value=''-1'>Select</option>";
                $.each(resp.d, function (key, value) {
                  appenddata += "<option value = '" + value.ClubID + "'>" + value.ClubName + " </option>";
                });
                $('#ddl-klubs').html(appenddata);
        },
        error: function (e) {
            $.mobile.loading("hide");
            console.log(e.message);
            // TODO: Use a friendlier error message below.
            me.$ctnErr.html("<p>Oops! Klubmodul had a problem and could not load klubs.  Please try again in a few minutes.</p>");
            me.$ctnErr.addClass("bi-ctn-err").slideDown();
            me.$ddlKlubs.addClass(invalidInputStyle);
        }
      });
};

Klubmodul.SignInController.prototype.emailAddressIsValid = function (email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
};

Klubmodul.SignInController.prototype.resetSignInForm = function () {
    var invisibleStyle = "bi-invisible",
        invalidInputStyle = "bi-invalid-input";
    this.$ctnErr.html("");
    this.$ctnErr.removeClass().addClass(invisibleStyle);
    this.$txtUserName.removeClass(invalidInputStyle);
    this.$txtPassword.removeClass(invalidInputStyle);
    this.$txtUserName.val("");
    this.$txtPassword.val("");
    this.$chkKeepSignedIn.prop("checked", false);
    this.$ddlKlubs.select("");
};

Klubmodul.SignInController.prototype.onSignInCommand = function () {
    var me = this,
        selectedKlubId = me.$ddlKlubs.val(),
        userName = me.$txtUserName.val().trim(),
        password = me.$txtPassword.val().trim(),
        invalidInput = false,
        invisibleStyle = "bi-invisible",
        invalidInputStyle = "bi-invalid-input";
    // Reset styles.
    me.$ctnErr.removeClass().addClass(invisibleStyle);
    me.$ddlKlubs.removeClass(invalidInputStyle);
    me.$txtUserName.removeClass(invalidInputStyle);
    me.$txtPassword.removeClass(invalidInputStyle);
    // Flag each invalid field.
    if (selectedKlubId.length === 0) {
        me.$ddlKlubs.addClass(invalidInputStyle);
        invalidInput = true;
    }
    if (userName.length === 0) {
        me.$txtUserName.addClass(invalidInputStyle);
        invalidInput = true;
    }
    if (password.length === 0) {
        me.$txtPassword.addClass(invalidInputStyle);
        invalidInput = true;
    }
    // Make sure that all the required fields have values.
    if (invalidInput) {
        me.$ctnErr.html("<p>Please enter all the required fields.</p>");
        me.$ctnErr.addClass("bi-ctn-err").slideDown();
        return;
    }
    /*
    if (!me.emailAddressIsValid(emailAddress)) {
        me.$ctnErr.html("<p>Please enter a valid email address.</p>");
        me.$ctnErr.addClass("bi-ctn-err").slideDown();
        me.$txtUserName.addClass(invalidInputStyle);
        return;
    }
    */
    $.mobile.loading("show");
    $.ajax({
        type: 'POST',
        url: Klubmodul.Settings.signInUrl,
        data: JSON.stringify({ username: userName, password: password, clubid: selectedKlubId }),
        contentType: "application/json",
        dataType: "json",
        crossDomain: true,
        success: function (resp) {
          if(resp != null && resp.d !=null)
          {
            $.mobile.loading("hide");
                // Create session.
                var today = new Date();
                var expirationDate = new Date();
                expirationDate.setTime(today.getTime() + Klubmodul.Settings.sessionTimeoutInMSec);
                Klubmodul.Session.getInstance().set({
                    userProfileModel: resp.d,
                    sessionId: resp.d.SessionId,
                    expirationDate: expirationDate,
                    keepSignedIn:me.$chkKeepSignedIn.is(":checked")
                });
                // Go to main menu.
                $.mobile.navigate(me.mainMenuPageId);
                return;
              }
              else
              {
                    $.mobile.loading("hide");
                    me.$ctnErr.html("<p>You entered a wrong credentials.  Please try again.</p>");
                    me.$ctnErr.addClass("bi-ctn-err").slideDown();
                    me.$txtUserName.addClass(invalidInputStyle);
              }
        },
        error: function (e) {
            $.mobile.loading("hide");
            console.log(e.message);
            // TODO: Use a friendlier error message below.
            me.$ctnErr.html("<p>Oops! Klubmodul had a problem and could not log you on.  Please try again in a few minutes.</p>");
            me.$ctnErr.addClass("bi-ctn-err").slideDown();
        }
    });
};
