var Klubmodul = Klubmodul || {};

// Begin boilerplate code generated with Cordova project.

var app = {
    // Application Constructor
    initialize: function () {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function () {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function () {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function (id) {

    }
};

app.initialize();

// End boilerplate code.

$(document).on("mobileinit", function (event, ui) {
    $.mobile.defaultPageTransition = "slide";
});

app.SignInController = new Klubmodul.SignInController();
app.UserProfileController = new Klubmodul.UserProfileController();

//$(document).delegate("#page-signup", "pagebeforeshow", function () {
//    // Reset the signup form.
//    app.signupController.resetSignUpForm();
//});

$(document).on("pagecontainerbeforeshow", function (event, ui) {
    if (typeof ui.toPage == "object") {
        switch (ui.toPage.attr("id")) {
            case "page-signin":
                //Check already signed in
                /*if (!ui.prevPage) {
                // Check session.keepSignedIn and redirect to main menu.
                var session = Klubmodul.Session.getInstance().get(),
                    today = new Date();
                if (session && session.keepSignedIn && new Date(session.expirationDate).getTime() > today.getTime()) {
                    ui.toPage = $("#page-memberdetails");                }
                  }*/

                // Reset the signup form.
                app.SignInController.resetSignInForm();
                break;

            case "page-memberdetails":
                app.UserProfileController.setUserProfile();
                break;
        }
    }
});

$(document).delegate("#page-signin", "pagebeforecreate", function () {

    app.SignInController.init();

    app.SignInController.$btnSubmit.off("tap").on("tap", function () {
        app.SignInController.onSignInCommand();
    });

});

$(document).delegate("#page-memberdetails", "pagebeforecreate", function () {

    app.UserProfileController.init();
});
