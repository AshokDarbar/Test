var Klubmodul = Klubmodul || {};
Klubmodul.Settings = Klubmodul.Settings || {};
Klubmodul.Settings.signInUrl = "https://quickpay.klubmodul.dk/admin/KlubModulAPI.asmx/Login"; //"http://127.0.0.1:30000/api/account/register";
Klubmodul.Settings.getAllKlubUrl = "https://quickpay.klubmodul.dk/admin/KlubModulAPI.asmx/GetAllClubs";
